// lab5_exeA
// ENSF 614 Fall 2022 LAB 5 - EXERCISE A

#include <iostream>
using namespace std;

#include "graphicsWorld.h"
#include "point.h"
#include "shape.h"
#include "square.h"
#include "rectangle.h"
#include "circle.h"
#include "curveCut.h"



int main(void)
{
    GraphicsWorld g;
    g.run();
}